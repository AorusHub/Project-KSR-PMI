describe('Admin - Reject Pendaftaran', () => {
  beforeEach(() => {
    cy.loginAsAdmin()
    cy.visit('/dashboard/admin/pendaftaran', { failOnStatusCode: false })
  })

  it('Admin dapat reject pendaftaran', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Reject"), button:contains("Tolak")').length > 0) {
        cy.get('button, a').contains(/reject|tolak/i).first().click()
        
        // Isi alasan penolakan
        cy.get('body').then(($modalBody) => {
          if ($modalBody.find('textarea[name="alasan"], textarea[name="reason"]').length > 0) {
            cy.get('textarea[name="alasan"], textarea[name="reason"]')
              .type('Tidak memenuhi syarat kesehatan untuk donor darah')
          }
        })
        
        cy.get('button').contains(/ya|reject|tolak/i).click()
        cy.contains(/berhasil|success|rejected/i, { timeout: 10000 }).should('be.visible')
      }
    })
  })

  it('Harus mengisi alasan penolakan', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Reject")').length > 0) {
        cy.get('button, a').contains(/reject|tolak/i).first().click()
        
        cy.get('body').then(($modalBody) => {
          if ($modalBody.find('textarea[name="alasan"]').length > 0) {
            // Submit tanpa isi alasan
            cy.get('button').contains(/ya|reject|tolak/i).click()
            cy.contains(/alasan.*wajib|reason.*required/i).should('be.visible')
          }
        })
      }
    })
  })

  it('Status pendaftaran berubah menjadi rejected', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Reject")').length > 0) {
        cy.get('button, a').contains(/reject/i).first().click()
        
        cy.get('body').then(($modalBody) => {
          if ($modalBody.find('textarea[name="alasan"]').length > 0) {
            cy.get('textarea[name="alasan"]').type('Test rejection reason')
          }
        })
        
        cy.get('button').contains(/ya|reject/i).click()
        cy.wait(1000)
        cy.contains(/rejected|ditolak/i).should('be.visible')
      }
    })
  })

  it('Dapat membatalkan reject', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Reject")').length > 0) {
        cy.get('button, a').contains(/reject/i).first().click()
        cy.get('button').contains(/batal|cancel/i).click()
        cy.url().should('include', '/pendaftaran')
      }
    })
  })

  it('Alasan penolakan tersimpan dan dapat dilihat', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Reject")').length > 0) {
        const alasanPenolakan = 'Kondisi kesehatan tidak memenuhi syarat'
        
        cy.get('button, a').contains(/reject/i).first().click()
        
        cy.get('body').then(($modalBody) => {
          if ($modalBody.find('textarea[name="alasan"]').length > 0) {
            cy.get('textarea[name="alasan"]').type(alasanPenolakan)
          }
        })
        
        cy.get('button').contains(/ya|reject/i).click()
        cy.wait(1000)
        
        // Cek detail untuk melihat alasan
        cy.get('a, button').contains(/detail/i).first().click()
        cy.contains(alasanPenolakan).should('be.visible')
      }
    })
  })

  it('Kuota kegiatan tidak berubah setelah reject', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Reject")').length > 0) {
        // Cek kuota sebelum
        cy.visit('/dashboard/admin/kegiatan-donor')
        cy.get('table tbody tr').first().find('td').eq(3).invoke('text').as('kuotaSebelum')
        
        // Reject pendaftaran
        cy.visit('/dashboard/admin/pendaftaran')
        cy.get('button, a').contains(/reject/i).first().click()
        cy.get('textarea[name="alasan"]').type('Test')
        cy.get('button').contains(/ya/i).click()
        cy.wait(1000)
        
        // Cek kuota sesudah (harus sama)
        cy.visit('/dashboard/admin/kegiatan-donor')
        cy.get('table tbody tr').first().find('td').eq(3).invoke('text').then((kuotaSesudah) => {
          cy.get('@kuotaSebelum').then((kuotaSebelum) => {
            expect(parseInt(kuotaSesudah)).to.equal(parseInt(kuotaSebelum))
          })
        })
      }
    })
  })

  it('Donor menerima notifikasi penolakan', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Reject")').length > 0) {
        cy.get('button, a').contains(/reject/i).first().click()
        cy.get('textarea[name="alasan"]').type('Test reason')
        cy.get('button').contains(/ya/i).click()
        cy.contains(/berhasil|notifikasi/i).should('be.visible')
      }
    })
  })
})