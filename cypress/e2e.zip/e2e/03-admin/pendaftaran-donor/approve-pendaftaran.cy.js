describe('Admin - Approve Pendaftaran', () => {
  beforeEach(() => {
    cy.loginAsAdmin()
    cy.visit('/dashboard/admin/pendaftaran', { failOnStatusCode: false })
  })

  it('Admin dapat approve pendaftaran yang pending', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Approve"), button:contains("Setujui")').length > 0) {
        cy.get('button, a').contains(/approve|setujui/i).first().click()
        
        // Konfirmasi jika ada
        cy.get('body').then(($confirmBody) => {
          if ($confirmBody.find('button:contains("Ya"), button:contains("Confirm")').length > 0) {
            cy.get('button').contains(/ya|confirm|setuju/i).click()
          }
        })
        
        cy.contains(/berhasil|success|approved/i, { timeout: 10000 }).should('be.visible')
      }
    })
  })

  it('Menampilkan konfirmasi sebelum approve', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Approve")').length > 0) {
        cy.get('button, a').contains(/approve|setujui/i).first().click()
        cy.contains(/yakin|confirm|approve/i).should('be.visible')
      }
    })
  })

  it('Status pendaftaran berubah menjadi approved', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Approve")').length > 0) {
        // Ambil row pendaftaran yang akan di-approve
        cy.get('table tbody tr').first().as('targetRow')
        
        cy.get('button, a').contains(/approve/i).first().click()
        
        cy.get('body').then(($confirmBody) => {
          if ($confirmBody.find('button:contains("Ya")').length > 0) {
            cy.get('button').contains(/ya/i).click()
          }
        })
        
        cy.wait(1000)
        cy.get('@targetRow').should('contain', /approved|disetujui/i)
      }
    })
  })

  it('Dapat membatalkan approve', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Approve")').length > 0) {
        cy.get('button, a').contains(/approve/i).first().click()
        cy.get('button').contains(/batal|cancel/i).click()
        cy.url().should('include', '/pendaftaran')
      }
    })
  })

  it('Kuota kegiatan berkurang setelah approve', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Approve")').length > 0) {
        // Cek kuota sebelum approve
        cy.visit('/dashboard/admin/kegiatan-donor')
        cy.get('table tbody tr').first().find('td').eq(3).invoke('text').as('kuotaSebelum')
        
        // Approve pendaftaran
        cy.visit('/dashboard/admin/pendaftaran')
        cy.get('button, a').contains(/approve/i).first().click()
        cy.get('button').contains(/ya/i).click()
        cy.wait(1000)
        
        // Cek kuota sesudah approve
        cy.visit('/dashboard/admin/kegiatan-donor')
        cy.get('table tbody tr').first().find('td').eq(3).invoke('text').then((kuotaSesudah) => {
          cy.get('@kuotaSebelum').then((kuotaSebelum) => {
            expect(parseInt(kuotaSesudah)).to.be.lessThan(parseInt(kuotaSebelum))
          })
        })
      }
    })
  })

  it('Tidak dapat approve jika kuota kegiatan penuh', () => {
    cy.get('body').then(($body) => {
      // Jika ada pendaftaran dengan kegiatan penuh
      if ($body.find('button:contains("Approve")[disabled]').length > 0) {
        cy.get('button:contains("Approve")[disabled]').should('exist')
      }
    })
  })

  it('Donor menerima notifikasi setelah di-approve', () => {
    // Test ini memerlukan implementasi notifikasi
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Approve")').length > 0) {
        cy.get('button, a').contains(/approve/i).first().click()
        cy.get('button').contains(/ya/i).click()
        cy.contains(/berhasil|notifikasi terkirim/i).should('be.visible')
      }
    })
  })
})