describe('Admin - Detail Pendaftaran', () => {
  beforeEach(() => {
    cy.loginAsAdmin()
    cy.visit('/dashboard/admin/pendaftaran', { failOnStatusCode: false })
  })

  it('Admin dapat melihat detail pendaftaran', () => {
    cy.get('body').then(($body) => {
      if ($body.find('a:contains("Detail"), button:contains("Detail")').length > 0) {
        cy.get('a, button').contains(/detail/i).first().click()
        cy.checkPageExists()
        cy.contains(/detail|pendaftaran/i).should('be.visible')
      }
    })
  })

  it('Detail menampilkan informasi donor', () => {
    cy.get('body').then(($body) => {
      if ($body.find('a:contains("Detail")').length > 0) {
        cy.get('a, button').contains(/detail/i).first().click()
        
        cy.contains(/nama|name/i).should('be.visible')
        cy.contains(/email/i).should('be.visible')
        cy.contains(/golongan darah|blood type/i).should('be.visible')
      }
    })
  })

  it('Detail menampilkan informasi kegiatan', () => {
    cy.get('body').then(($body) => {
      if ($body.find('a:contains("Detail")').length > 0) {
        cy.get('a, button').contains(/detail/i).first().click()
        
        cy.contains(/kegiatan|event/i).should('be.visible')
        cy.contains(/tanggal|date/i).should('be.visible')
        cy.contains(/lokasi|location/i).should('be.visible')
      }
    })
  })

  it('Detail menampilkan status pendaftaran', () => {
    cy.get('body').then(($body) => {
      if ($body.find('a:contains("Detail")').length > 0) {
        cy.get('a, button').contains(/detail/i).first().click()
        cy.contains(/status|pending|approved|rejected/i).should('be.visible')
      }
    })
  })

  it('Menampilkan waktu pendaftaran', () => {
    cy.get('body').then(($body) => {
      if ($body.find('a:contains("Detail")').length > 0) {
        cy.get('a, button').contains(/detail/i).first().click()
        cy.contains(/tanggal.*daftar|registered at|created at/i).should('be.visible')
      }
    })
  })

  it('Dapat approve dari halaman detail', () => {
    cy.get('body').then(($body) => {
      if ($body.find('a:contains("Detail")').length > 0) {
        cy.get('a, button').contains(/detail/i).first().click()
        
        cy.get('body').then(($detailBody) => {
          if ($detailBody.find('button:contains("Approve")').length > 0) {
            cy.get('button').contains(/approve|setujui/i).should('be.visible')
          }
        })
      }
    })
  })

  it('Dapat reject dari halaman detail', () => {
    cy.get('body').then(($body) => {
      if ($body.find('a:contains("Detail")').length > 0) {
        cy.get('a, button').contains(/detail/i).first().click()
        
        cy.get('body').then(($detailBody) => {
          if ($detailBody.find('button:contains("Reject")').length > 0) {
            cy.get('button').contains(/reject|tolak/i).should('be.visible')
          }
        })
      }
    })
  })

  it('Dapat kembali ke list pendaftaran', () => {
    cy.get('body').then(($body) => {
      if ($body.find('a:contains("Detail")').length > 0) {
        cy.get('a, button').contains(/detail/i).first().click()
        cy.get('a, button').contains(/kembali|back/i).click()
        cy.url().should('include', '/pendaftaran')
      }
    })
  })
})