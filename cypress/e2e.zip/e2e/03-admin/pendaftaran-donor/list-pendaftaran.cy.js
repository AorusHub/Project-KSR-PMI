describe('Admin - List Pendaftaran Donor', () => {
  beforeEach(() => {
    cy.loginAsAdmin()
    cy.visit('/dashboard/admin/pendaftaran', { failOnStatusCode: false })
  })

  it('Admin dapat mengakses halaman daftar pendaftaran', () => {
    cy.checkPageExists()
    cy.contains(/pendaftaran|registrasi/i).should('be.visible')
  })

  it('Menampilkan tabel/list pendaftaran donor', () => {
    cy.get('table, .card, .pendaftaran-item').should('exist')
  })

  it('Setiap pendaftaran menampilkan informasi penting', () => {
    cy.get('body').then(($body) => {
      if ($body.find('table tbody tr, .pendaftaran-item').length > 0) {
        cy.contains(/nama|donor|kegiatan|status/i).should('be.visible')
      }
    })
  })

  it('Menampilkan status pendaftaran (pending/approved/rejected)', () => {
    cy.get('body').then(($body) => {
      if ($body.find('table tbody tr').length > 0) {
        cy.contains(/pending|approved|rejected|menunggu|disetujui|ditolak/i).should('be.visible')
      }
    })
  })

  it('Dapat filter pendaftaran berdasarkan status', () => {
    cy.get('body').then(($body) => {
      if ($body.find('select[name="status"]').length > 0) {
        cy.get('select[name="status"]').select('pending')
        cy.get('button').contains(/filter|terapkan/i).click()
        cy.wait(500)
      }
    })
  })

  it('Dapat filter berdasarkan kegiatan', () => {
    cy.get('body').then(($body) => {
      if ($body.find('select[name="kegiatan_id"]').length > 0) {
        cy.get('select[name="kegiatan_id"]').select(1)
        cy.get('button').contains(/filter/i).click()
      }
    })
  })

  it('Dapat filter berdasarkan tanggal pendaftaran', () => {
    cy.get('body').then(($body) => {
      if ($body.find('input[name="start_date"]').length > 0) {
        cy.get('input[name="start_date"]').type('2025-12-01')
        cy.get('input[name="end_date"]').type('2025-12-31')
        cy.get('button').contains(/filter/i).click()
      }
    })
  })

  it('Dapat mencari pendaftaran berdasarkan nama donor', () => {
    cy.get('body').then(($body) => {
      if ($body.find('input[type="search"]').length > 0) {
        cy.get('input[type="search"]').type('donor')
        cy.get('button[type="submit"]').click()
        cy.wait(500)
      }
    })
  })

  it('Menampilkan tombol approve untuk pendaftaran pending', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Approve"), button:contains("Setujui")').length > 0) {
        cy.get('button, a').contains(/approve|setujui/i).should('be.visible')
      }
    })
  })

  it('Menampilkan tombol reject untuk pendaftaran pending', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Reject"), button:contains("Tolak")').length > 0) {
        cy.get('button, a').contains(/reject|tolak/i).should('be.visible')
      }
    })
  })

  it('Menampilkan pagination', () => {
    cy.get('body').then(($body) => {
      if ($body.find('.pagination').length > 0) {
        cy.get('.pagination').should('be.visible')
      }
    })
  })

  it('Menampilkan jumlah total pendaftaran', () => {
    cy.contains(/total|jumlah/i).should('be.visible')
  })
})