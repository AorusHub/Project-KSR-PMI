describe('Admin - Approve Donor', () => {
  beforeEach(() => {
    cy.loginAsAdmin()
    cy.visit('/dashboard/admin/donor', { failOnStatusCode: false })
  })

  it('Admin dapat approve donor yang pending', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Approve"), button:contains("Setujui")').length > 0) {
        cy.get('button, a').contains(/approve|setujui|verifikasi/i).first().click()
        
        // Konfirmasi jika ada
        cy.get('body').then(($confirmBody) => {
          if ($confirmBody.find('button:contains("Ya")').length > 0) {
            cy.get('button').contains(/ya|confirm/i).click()
          }
        })
        
        cy.contains(/berhasil|success|approved/i, { timeout: 10000 }).should('be.visible')
      }
    })
  })

  it('Status donor berubah menjadi approved', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Approve")').length > 0) {
        cy.get('button, a').contains(/approve/i).first().click()
        
        cy.get('body').then(($confirmBody) => {
          if ($confirmBody.find('button:contains("Ya")').length > 0) {
            cy.get('button').contains(/ya/i).click()
          }
        })
        
        cy.wait(1000)
        cy.contains(/approved|disetujui|aktif/i).should('be.visible')
      }
    })
  })

  it('Menampilkan konfirmasi sebelum approve', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Approve")').length > 0) {
        cy.get('button, a').contains(/approve/i).first().click()
        cy.contains(/yakin|confirm/i).should('be.visible')
      }
    })
  })

  it('Dapat membatalkan approve', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Approve")').length > 0) {
        cy.get('button, a').contains(/approve/i).first().click()
        cy.get('button').contains(/batal|cancel/i).click()
        cy.url().should('include', '/donor')
      }
    })
  })
})