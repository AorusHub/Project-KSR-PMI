describe('User Logout', () => {
  it('Admin dapat logout dengan benar', () => {
    cy.loginAsAdmin()
    cy.url().should('include', '/dashboard')
    
    // Cari tombol/link logout
    cy.get('body').then(($body) => {
      if ($body.find('a[href*="logout"]').length) {
        cy.get('a[href*="logout"]').click()
      } else if ($body.find('button:contains("Logout")').length) {
        cy.get('button').contains(/logout|keluar/i).click()
      } else if ($body.find('form[action*="logout"]').length) {
        cy.get('form[action*="logout"]').submit()
      }
    })
    
    cy.url().should('include', '/login')
    
  })

  it('Donor dapat logout dengan benar', () => {
    cy.loginAsDonor()
    cy.url().should('include', '/dashboard')
    
    cy.get('body').then(($body) => {
      if ($body.find('a[href*="logout"]').length) {
        cy.get('a[href*="logout"]').click()
      } else if ($body.find('button:contains("Logout")').length) {
        cy.get('button').contains(/logout|keluar/i).click()
      } else if ($body.find('form[action*="logout"]').length) {
        cy.get('form[action*="logout"]').submit()
      }
    })
    
    cy.url().should('include', '/login')
  })

  it('Setelah logout tidak bisa akses dashboard tanpa login lagi', () => {
    cy.loginAsDonor()
    cy.logout()
    
    cy.visit('/dashboard/donor', { failOnStatusCode: false })
    cy.url().should('include', '/login')
  })

  it('Session dihapus setelah logout', () => {
    cy.loginAsAdmin()
    cy.logout()
    
    cy.getCookie('laravel_session').should('not.exist')
  })
})