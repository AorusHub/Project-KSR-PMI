describe('Authentication Validation', () => {
  context('Login Validation', () => {
    beforeEach(() => {
      cy.visit('/login')
    })

    it('Email wajib diisi', () => {
      cy.get('input[name="password"]').type('password123')
      cy.get('button[type="submit"]').click()
      
      cy.get('input[name="email"]:invalid').should('exist')
    })

    it('Password wajib diisi', () => {
      cy.get('input[name="email"]').type('test@test.com')
      cy.get('button[type="submit"]').click()
      
      cy.get('input[name="password"]:invalid').should('exist')
    })

    it('Email harus format yang valid', () => {
      cy.get('input[name="email"]').type('invalidemail')
      cy.get('button[type="submit"]').click()
      
      cy.get('input[name="email"]:invalid').should('exist')
    })
  })

  context('Register Validation', () => {
    beforeEach(() => {
      cy.visit('/register')
    })

    it('Nama wajib diisi', () => {
      cy.get('input[name="email"]').type('test@test.com')
      cy.get('input[name="password"]').type('password123')
      cy.get('button[type="submit"]').click()
      
      cy.contains(/nama.*wajib|required/i).should('be.visible')
    })

    it('Email wajib diisi', () => {
      cy.get('input[name="name"]').type('Test User')
      cy.get('input[name="password"]').type('password123')
      cy.get('button[type="submit"]').click()
      
      cy.get('input[name="email"]:invalid').should('exist')
    })

    it('Password minimal 8 karakter', () => {
      cy.get('input[name="name"]').type('Test User')
      cy.get('input[name="email"]').type('test@test.com')
      cy.get('input[name="password"]').type('123')
      cy.get('button[type="submit"]').click()
      
      cy.contains(/password.*minimal|at least 8/i).should('be.visible')
    })

    it('Password confirmation harus sama', () => {
      cy.get('input[name="name"]').type('Test User')
      cy.get('input[name="email"]').type('test@test.com')
      cy.get('input[name="password"]').type('password123')
      cy.get('input[name="password_confirmation"]').type('different')
      cy.get('button[type="submit"]').click()
      
      cy.contains(/password.*tidak sama|must match/i).should('be.visible')
    })

    it('Email harus unique', () => {
      cy.fixture('users').then((users) => {
        cy.get('input[name="name"]').type('Test User')
        cy.get('input[name="email"]').type(users.donor.email)
        cy.get('input[name="password"]').type('password123')
        cy.get('input[name="password_confirmation"]').type('password123')
        cy.get('button[type="submit"]').click()
        
        cy.contains(/email.*sudah|already taken/i).should('be.visible')
      })
    })
  })
})