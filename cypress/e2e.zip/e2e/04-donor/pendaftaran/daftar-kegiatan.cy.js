describe('Donor - Daftar Kegiatan', () => {
  beforeEach(() => {
    cy.loginAsDonor()
    cy.visit('/dashboard/donor/kegiatan', { failOnStatusCode: false })
  })

  it('Donor dapat melihat daftar kegiatan yang tersedia', () => {
    cy.checkPageExists()
    cy.contains(/kegiatan|donor darah/i).should('be.visible')
  })

  it('Menampilkan list kegiatan yang akan datang', () => {
    cy.get('table, .card, .kegiatan-item').should('exist')
  })

  it('Setiap kegiatan menampilkan informasi lengkap', () => {
    cy.get('body').then(($body) => {
      if ($body.find('table tbody tr, .kegiatan-item').length > 0) {
        cy.contains(/nama.*kegiatan|tanggal|lokasi|kuota/i).should('be.visible')
      }
    })
  })

  it('Menampilkan tombol daftar untuk kegiatan yang tersedia', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Daftar"), a:contains("Daftar")').length > 0) {
        cy.get('button, a').contains(/daftar|register/i).should('be.visible')
      }
    })
  })

  it('Donor dapat mendaftar ke kegiatan', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Daftar")').length > 0) {
        cy.get('button, a').contains(/daftar/i).first().click()
        
        // Konfirmasi jika ada
        cy.get('body').then(($confirmBody) => {
          if ($confirmBody.find('button:contains("Ya"), button:contains("Confirm")').length > 0) {
            cy.get('button').contains(/ya|confirm|daftar/i).click()
          }
        })
        
        cy.contains(/berhasil|success|registered/i, { timeout: 10000 }).should('be.visible')
      }
    })
  })

  it('Menampilkan modal konfirmasi sebelum mendaftar', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Daftar")').length > 0) {
        cy.get('button, a').contains(/daftar/i).first().click()
        cy.contains(/yakin|confirm/i).should('be.visible')
      }
    })
  })

  it('Donor dapat membatalkan pendaftaran dari modal', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Daftar")').length > 0) {
        cy.get('button, a').contains(/daftar/i).first().click()
        cy.get('button').contains(/batal|cancel/i).click()
        cy.url().should('include', '/kegiatan')
      }
    })
  })

  it('Tidak dapat mendaftar ke kegiatan yang sama 2 kali', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Daftar")').length > 0) {
        // Daftar pertama kali
        cy.get('button, a').contains(/daftar/i).first().click()
        cy.get('button').contains(/ya/i).click()
        cy.wait(2000)
        
        // Coba daftar lagi
        cy.visit('/dashboard/donor/kegiatan')
        cy.get('button, a').contains(/daftar/i).first().click()
        cy.get('button').contains(/ya/i).click()
        
        cy.contains(/sudah terdaftar|already registered/i).should('be.visible')
      }
    })
  })

  it('Tidak dapat mendaftar jika kuota penuh', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Daftar")[disabled], .disabled').length > 0) {
        cy.get('button:contains("Daftar")[disabled]').should('exist')
        cy.contains(/penuh|full/i).should('be.visible')
      }
    })
  })

  it('Menampilkan sisa kuota untuk setiap kegiatan', () => {
    cy.contains(/kuota|tersisa|available/i).should('be.visible')
  })

  it('Dapat melihat detail kegiatan sebelum mendaftar', () => {
    cy.get('body').then(($body) => {
      if ($body.find('a:contains("Detail"), button:contains("Detail")').length > 0) {
        cy.get('a, button').contains(/detail/i).first().click()
        cy.contains(/detail|deskripsi/i).should('be.visible')
      }
    })
  })

  it('Dapat filter kegiatan berdasarkan tanggal', () => {
    cy.get('body').then(($body) => {
      if ($body.find('input[name="tanggal"]').length > 0) {
        cy.get('input[name="tanggal"]').type('2025-12-25')
        cy.get('button').contains(/filter|cari/i).click()
      }
    })
  })

  it('Dapat search kegiatan berdasarkan nama', () => {
    cy.get('body').then(($body) => {
      if ($body.find('input[type="search"]').length > 0) {
        cy.get('input[type="search"]').type('Donor')
        cy.get('button[type="submit"]').click()
      }
    })
  })
})