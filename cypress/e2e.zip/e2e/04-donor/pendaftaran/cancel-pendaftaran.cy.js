describe('Donor - Cancel Pendaftaran', () => {
  beforeEach(() => {
    cy.loginAsDonor()
    cy.visit('/dashboard/donor/pendaftaran', { failOnStatusCode: false })
  })

  it('Donor dapat membatalkan pendaftaran yang pending', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Batal"), a:contains("Batal")').length > 0) {
        cy.get('button, a').contains(/batal|cancel/i).first().click()
        
        // Konfirmasi
        cy.get('body').then(($confirmBody) => {
          if ($confirmBody.find('button:contains("Ya")').length > 0) {
            cy.get('button').contains(/ya|confirm/i).click()
          }
        })
        
        cy.contains(/berhasil.*dibatalkan|cancelled/i, { timeout: 10000 }).should('be.visible')
      }
    })
  })

  it('Menampilkan konfirmasi sebelum membatalkan', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Batal")').length > 0) {
        cy.get('button, a').contains(/batal/i).first().click()
        cy.contains(/yakin.*batal|confirm.*cancel/i).should('be.visible')
      }
    })
  })

  it('Dapat membatalkan proses cancel', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Batal")').length > 0) {
        cy.get('button, a').contains(/batal/i).first().click()
        cy.get('button').contains(/tidak|no|cancel/i).click()
        cy.url().should('include', '/pendaftaran')
      }
    })
  })

  it('Pendaftaran dihapus dari list setelah dibatalkan', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Batal")').length > 0) {
        // Ambil nama kegiatan
        cy.get('table tbody tr, .pendaftaran-item').first()
          .find('td, .nama-kegiatan').first()
          .invoke('text').as('namaKegiatan')
        
        cy.get('button, a').contains(/batal/i).first().click()
        cy.get('button').contains(/ya/i).click()
        cy.wait(2000)
        
        // Verifikasi tidak ada lagi
        cy.get('@namaKegiatan').then((namaKegiatan) => {
          cy.get('table tbody tr, .pendaftaran-item').should('not.contain', namaKegiatan)
        })
      }
    })
  })

  it('Kuota kegiatan bertambah setelah pendaftaran dibatalkan', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Batal")').length > 0) {
        // Cek kuota sebelum cancel
        cy.visit('/dashboard/donor/kegiatan')
        cy.get('table tbody tr').first().find('td').contains(/kuota/i).invoke('text').as('kuotaSebelum')
        
        // Cancel pendaftaran
        cy.visit('/dashboard/donor/pendaftaran')
        cy.get('button, a').contains(/batal/i).first().click()
        cy.get('button').contains(/ya/i).click()
        cy.wait(2000)
        
        // Cek kuota sesudah
        cy.visit('/dashboard/donor/kegiatan')
        cy.get('table tbody tr').first().find('td').contains(/kuota/i).invoke('text').then((kuotaSesudah) => {
          cy.get('@kuotaSebelum').then((kuotaSebelum) => {
            // Kuota harus bertambah
            cy.log(`Kuota sebelum: ${kuotaSebelum}, Kuota sesudah: ${kuotaSesudah}`)
          })
        })
      }
    })
  })

  it('Tidak dapat membatalkan pendaftaran yang sudah approved', () => {
    cy.get('body').then(($body) => {
      // Cari pendaftaran approved
      if ($body.text().match(/approved|disetujui/i)) {
        cy.get('tr:contains("Approved"), .pendaftaran-item:contains("Approved")').then(($approved) => {
          // Tombol batal tidak ada atau disabled
          expect($approved.find('button:contains("Batal")').length).to.equal(0)
        })
      }
    })
  })

  it('Tidak dapat membatalkan pendaftaran yang sudah ditolak', () => {
    cy.get('body').then(($body) => {
      if ($body.text().match(/rejected|ditolak/i)) {
        cy.get('tr:contains("Rejected"), .pendaftaran-item:contains("Rejected")').then(($rejected) => {
          expect($rejected.find('button:contains("Batal")').length).to.equal(0)
        })
      }
    })
  })

  it('Hanya dapat membatalkan H-3 sebelum kegiatan', () => {
    // Test untuk business rule: tidak bisa cancel jika kurang dari 3 hari
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Batal")[disabled]').length > 0) {
        cy.get('button:contains("Batal")[disabled]').should('exist')
        cy.contains(/tidak dapat.*dibatalkan|cannot cancel/i).should('be.visible')
      }
    })
  })
})