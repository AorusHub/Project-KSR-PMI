describe('Donor - View Status Pendaftaran', () => {
  beforeEach(() => {
    cy.loginAsDonor()
    cy.visit('/dashboard/donor/pendaftaran', { failOnStatusCode: false })
  })

  it('Donor dapat melihat halaman status pendaftaran', () => {
    cy.checkPageExists()
    cy.contains(/pendaftaran|status/i).should('be.visible')
  })

  it('Menampilkan list semua pendaftaran donor', () => {
    cy.get('table, .card, .pendaftaran-item').should('exist')
  })

  it('Setiap pendaftaran menampilkan nama kegiatan', () => {
    cy.get('body').then(($body) => {
      if ($body.find('table tbody tr, .pendaftaran-item').length > 0) {
        cy.contains(/nama.*kegiatan|kegiatan|event/i).should('be.visible')
      }
    })
  })

  it('Menampilkan status pendaftaran', () => {
    cy.get('body').then(($body) => {
      if ($body.find('table tbody tr').length > 0) {
        cy.contains(/pending|approved|rejected|menunggu|disetujui|ditolak/i).should('be.visible')
      }
    })
  })

  it('Status ditampilkan dengan badge/label berwarna', () => {
    cy.get('body').then(($body) => {
      if ($body.find('.badge, .label, .status-badge').length > 0) {
        cy.get('.badge, .label, .status-badge').should('be.visible')
      }
    })
  })

  it('Menampilkan tanggal pendaftaran', () => {
    cy.get('body').then(($body) => {
      if ($body.find('table tbody tr').length > 0) {
        cy.contains(/tanggal.*daftar|registered|created/i).should('be.visible')
      }
    })
  })

  it('Menampilkan tanggal kegiatan', () => {
    cy.get('body').then(($body) => {
      if ($body.find('table tbody tr').length > 0) {
        cy.contains(/tanggal.*kegiatan|event date/i).should('be.visible')
      }
    })
  })

  it('Menampilkan lokasi kegiatan', () => {
    cy.contains(/lokasi|location/i).should('be.visible')
  })

  it('Dapat melihat detail pendaftaran', () => {
    cy.get('body').then(($body) => {
      if ($body.find('a:contains("Detail"), button:contains("Detail")').length > 0) {
        cy.get('a, button').contains(/detail/i).first().click()
        cy.checkPageExists()
      }
    })
  })

  it('Menampilkan tombol batal untuk pendaftaran pending', () => {
    cy.get('body').then(($body) => {
      if ($body.find('button:contains("Batal"), a:contains("Batal")').length > 0) {
        cy.get('button, a').contains(/batal|cancel/i).should('be.visible')
      }
    })
  })

  it('Menampilkan alasan jika pendaftaran ditolak', () => {
    cy.get('body').then(($body) => {
      if ($body.text().match(/ditolak|rejected/i)) {
        cy.get('body').then(($detailBody) => {
          if ($detailBody.text().match(/alasan|reason/i)) {
            cy.contains(/alasan|reason/i).should('be.visible')
          }
        })
      }
    })
  })

  it('Dapat filter berdasarkan status', () => {
    cy.get('body').then(($body) => {
      if ($body.find('select[name="status"]').length > 0) {
        cy.get('select[name="status"]').select('pending')
        cy.get('button').contains(/filter/i).click()
      }
    })
  })

  it('Menampilkan pesan jika belum ada pendaftaran', () => {
    cy.get('body').then(($body) => {
      if (!$body.find('table tbody tr, .pendaftaran-item').length) {
        cy.contains(/belum ada|no data|tidak ada pendaftaran/i).should('be.visible')
      }
    })
  })

  it('Menampilkan jumlah total pendaftaran', () => {
    cy.get('body').then(($body) => {
      if ($body.text().match(/total|jumlah/i)) {
        cy.contains(/total|jumlah/i).should('be.visible')
      }
    })
  })
})